package com.example.common;

public interface Constants {

    String TOKEN = "token";

    String USER_DEFAULT_PASSWORD = "123";

    String IS_FOLDER = "是";

    String NOT_FOLDER = "否";

    String FILE_TYPE_FOLDER = "folder";

}
